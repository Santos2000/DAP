﻿namespace Projeto_DAplicacoes
{
	partial class GerirPedidos
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(GerirPedidos));
			this.menuStrip = new System.Windows.Forms.MenuStrip();
			this.menuToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.gerirClientesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.gerirToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.gerirArranjosToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.gerirFornecedoresToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.sairToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.panel1 = new System.Windows.Forms.Panel();
			this.button1 = new System.Windows.Forms.Button();
			this.lbPedidos = new System.Windows.Forms.ListBox();
			this.groupBox1 = new System.Windows.Forms.GroupBox();
			this.cbPeca = new System.Windows.Forms.ComboBox();
			this.label13 = new System.Windows.Forms.Label();
			this.cbTipoPedido = new System.Windows.Forms.ComboBox();
			this.label2 = new System.Windows.Forms.Label();
			this.cbCliente = new System.Windows.Forms.ComboBox();
			this.button2 = new System.Windows.Forms.Button();
			this.label6 = new System.Windows.Forms.Label();
			this.label1 = new System.Windows.Forms.Label();
			this.textBox6 = new System.Windows.Forms.TextBox();
			this.gpClientes = new System.Windows.Forms.GroupBox();
			this.button3 = new System.Windows.Forms.Button();
			this.button4 = new System.Windows.Forms.Button();
			this.label12 = new System.Windows.Forms.Label();
			this.label11 = new System.Windows.Forms.Label();
			this.label10 = new System.Windows.Forms.Label();
			this.checkBox2 = new System.Windows.Forms.CheckBox();
			this.checkBox1 = new System.Windows.Forms.CheckBox();
			this.textBox1 = new System.Windows.Forms.TextBox();
			this.label9 = new System.Windows.Forms.Label();
			this.label8 = new System.Windows.Forms.Label();
			this.label7 = new System.Windows.Forms.Label();
			this.label5 = new System.Windows.Forms.Label();
			this.label4 = new System.Windows.Forms.Label();
			this.label3 = new System.Windows.Forms.Label();
			this.menuStrip.SuspendLayout();
			this.panel1.SuspendLayout();
			this.groupBox1.SuspendLayout();
			this.gpClientes.SuspendLayout();
			this.SuspendLayout();
			// 
			// menuStrip
			// 
			this.menuStrip.BackColor = System.Drawing.Color.LightGray;
			this.menuStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.menuToolStripMenuItem});
			this.menuStrip.Location = new System.Drawing.Point(0, 0);
			this.menuStrip.Name = "menuStrip";
			this.menuStrip.Size = new System.Drawing.Size(892, 24);
			this.menuStrip.TabIndex = 2;
			this.menuStrip.Text = "menuStrip1";
			// 
			// menuToolStripMenuItem
			// 
			this.menuToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.gerirClientesToolStripMenuItem,
            this.gerirToolStripMenuItem,
            this.gerirArranjosToolStripMenuItem,
            this.gerirFornecedoresToolStripMenuItem,
            this.sairToolStripMenuItem});
			this.menuToolStripMenuItem.Name = "menuToolStripMenuItem";
			this.menuToolStripMenuItem.Size = new System.Drawing.Size(50, 20);
			this.menuToolStripMenuItem.Text = "Menu";
			// 
			// gerirClientesToolStripMenuItem
			// 
			this.gerirClientesToolStripMenuItem.Name = "gerirClientesToolStripMenuItem";
			this.gerirClientesToolStripMenuItem.Size = new System.Drawing.Size(173, 22);
			this.gerirClientesToolStripMenuItem.Text = "Gerir Clientes";
			this.gerirClientesToolStripMenuItem.Click += new System.EventHandler(this.gerirClientesToolStripMenuItem_Click);
			// 
			// gerirToolStripMenuItem
			// 
			this.gerirToolStripMenuItem.Name = "gerirToolStripMenuItem";
			this.gerirToolStripMenuItem.Size = new System.Drawing.Size(173, 22);
			this.gerirToolStripMenuItem.Text = "Gerir Pedidos";
			// 
			// gerirArranjosToolStripMenuItem
			// 
			this.gerirArranjosToolStripMenuItem.Name = "gerirArranjosToolStripMenuItem";
			this.gerirArranjosToolStripMenuItem.Size = new System.Drawing.Size(173, 22);
			this.gerirArranjosToolStripMenuItem.Text = "Gerir Arranjos";
			// 
			// gerirFornecedoresToolStripMenuItem
			// 
			this.gerirFornecedoresToolStripMenuItem.Name = "gerirFornecedoresToolStripMenuItem";
			this.gerirFornecedoresToolStripMenuItem.Size = new System.Drawing.Size(173, 22);
			this.gerirFornecedoresToolStripMenuItem.Text = "Gerir Fornecedores";
			this.gerirFornecedoresToolStripMenuItem.Click += new System.EventHandler(this.gerirFornecedoresToolStripMenuItem_Click);
			// 
			// sairToolStripMenuItem
			// 
			this.sairToolStripMenuItem.Name = "sairToolStripMenuItem";
			this.sairToolStripMenuItem.Size = new System.Drawing.Size(173, 22);
			this.sairToolStripMenuItem.Text = "Sair";
			this.sairToolStripMenuItem.Click += new System.EventHandler(this.sairToolStripMenuItem_Click);
			// 
			// panel1
			// 
			this.panel1.BackColor = System.Drawing.Color.LightGray;
			this.panel1.Controls.Add(this.button1);
			this.panel1.Dock = System.Windows.Forms.DockStyle.Bottom;
			this.panel1.Location = new System.Drawing.Point(0, 449);
			this.panel1.Name = "panel1";
			this.panel1.Size = new System.Drawing.Size(892, 38);
			this.panel1.TabIndex = 3;
			// 
			// button1
			// 
			this.button1.BackColor = System.Drawing.Color.Transparent;
			this.button1.Image = ((System.Drawing.Image)(resources.GetObject("button1.Image")));
			this.button1.Location = new System.Drawing.Point(0, 0);
			this.button1.Name = "button1";
			this.button1.Size = new System.Drawing.Size(45, 38);
			this.button1.TabIndex = 2;
			this.button1.UseVisualStyleBackColor = false;
			// 
			// lbPedidos
			// 
			this.lbPedidos.FormattingEnabled = true;
			this.lbPedidos.Location = new System.Drawing.Point(330, 29);
			this.lbPedidos.Name = "lbPedidos";
			this.lbPedidos.Size = new System.Drawing.Size(267, 407);
			this.lbPedidos.TabIndex = 29;
			// 
			// groupBox1
			// 
			this.groupBox1.Controls.Add(this.cbPeca);
			this.groupBox1.Controls.Add(this.label13);
			this.groupBox1.Controls.Add(this.cbTipoPedido);
			this.groupBox1.Controls.Add(this.label2);
			this.groupBox1.Controls.Add(this.cbCliente);
			this.groupBox1.Controls.Add(this.button2);
			this.groupBox1.Controls.Add(this.label6);
			this.groupBox1.Controls.Add(this.label1);
			this.groupBox1.Controls.Add(this.textBox6);
			this.groupBox1.Location = new System.Drawing.Point(12, 27);
			this.groupBox1.Name = "groupBox1";
			this.groupBox1.Size = new System.Drawing.Size(297, 409);
			this.groupBox1.TabIndex = 26;
			this.groupBox1.TabStop = false;
			this.groupBox1.Text = "Resgistar Pedido";
			// 
			// cbPeca
			// 
			this.cbPeca.FormattingEnabled = true;
			this.cbPeca.Location = new System.Drawing.Point(6, 141);
			this.cbPeca.Name = "cbPeca";
			this.cbPeca.Size = new System.Drawing.Size(286, 21);
			this.cbPeca.TabIndex = 20;
			// 
			// label13
			// 
			this.label13.AutoSize = true;
			this.label13.Location = new System.Drawing.Point(132, 125);
			this.label13.Name = "label13";
			this.label13.Size = new System.Drawing.Size(35, 13);
			this.label13.TabIndex = 19;
			this.label13.Text = "Peça:";
			// 
			// cbTipoPedido
			// 
			this.cbTipoPedido.FormattingEnabled = true;
			this.cbTipoPedido.Location = new System.Drawing.Point(5, 87);
			this.cbTipoPedido.Name = "cbTipoPedido";
			this.cbTipoPedido.Size = new System.Drawing.Size(286, 21);
			this.cbTipoPedido.TabIndex = 18;
			// 
			// label2
			// 
			this.label2.AutoSize = true;
			this.label2.Location = new System.Drawing.Point(113, 71);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(82, 13);
			this.label2.TabIndex = 17;
			this.label2.Text = "Tipo de Pedido:";
			// 
			// cbCliente
			// 
			this.cbCliente.FormattingEnabled = true;
			this.cbCliente.Location = new System.Drawing.Point(6, 38);
			this.cbCliente.Name = "cbCliente";
			this.cbCliente.Size = new System.Drawing.Size(284, 21);
			this.cbCliente.TabIndex = 16;
			// 
			// button2
			// 
			this.button2.Location = new System.Drawing.Point(12, 377);
			this.button2.Name = "button2";
			this.button2.Size = new System.Drawing.Size(279, 23);
			this.button2.TabIndex = 2;
			this.button2.Text = "Adicionar pedido";
			this.button2.UseVisualStyleBackColor = true;
			this.button2.Click += new System.EventHandler(this.button2_Click);
			// 
			// label6
			// 
			this.label6.AutoSize = true;
			this.label6.Location = new System.Drawing.Point(114, 296);
			this.label6.Name = "label6";
			this.label6.Size = new System.Drawing.Size(73, 13);
			this.label6.TabIndex = 13;
			this.label6.Text = "Observações:";
			// 
			// label1
			// 
			this.label1.AutoSize = true;
			this.label1.Location = new System.Drawing.Point(132, 22);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(42, 13);
			this.label1.TabIndex = 3;
			this.label1.Text = "Cliente:";
			// 
			// textBox6
			// 
			this.textBox6.Location = new System.Drawing.Point(6, 312);
			this.textBox6.Multiline = true;
			this.textBox6.Name = "textBox6";
			this.textBox6.Size = new System.Drawing.Size(285, 59);
			this.textBox6.TabIndex = 12;
			// 
			// gpClientes
			// 
			this.gpClientes.Controls.Add(this.button3);
			this.gpClientes.Controls.Add(this.button4);
			this.gpClientes.Controls.Add(this.label12);
			this.gpClientes.Controls.Add(this.label11);
			this.gpClientes.Controls.Add(this.label10);
			this.gpClientes.Controls.Add(this.checkBox2);
			this.gpClientes.Controls.Add(this.checkBox1);
			this.gpClientes.Controls.Add(this.textBox1);
			this.gpClientes.Controls.Add(this.label9);
			this.gpClientes.Controls.Add(this.label8);
			this.gpClientes.Controls.Add(this.label7);
			this.gpClientes.Controls.Add(this.label5);
			this.gpClientes.Controls.Add(this.label4);
			this.gpClientes.Controls.Add(this.label3);
			this.gpClientes.Location = new System.Drawing.Point(623, 29);
			this.gpClientes.Name = "gpClientes";
			this.gpClientes.Size = new System.Drawing.Size(256, 412);
			this.gpClientes.TabIndex = 28;
			this.gpClientes.TabStop = false;
			this.gpClientes.Text = "Dados do Pedido";
			// 
			// button3
			// 
			this.button3.Location = new System.Drawing.Point(135, 358);
			this.button3.Name = "button3";
			this.button3.Size = new System.Drawing.Size(112, 49);
			this.button3.TabIndex = 13;
			this.button3.Text = "Atualizar Pedido";
			this.button3.UseVisualStyleBackColor = true;
			// 
			// button4
			// 
			this.button4.Location = new System.Drawing.Point(9, 358);
			this.button4.Name = "button4";
			this.button4.Size = new System.Drawing.Size(112, 49);
			this.button4.TabIndex = 12;
			this.button4.Text = "Apagar Pedido";
			this.button4.UseVisualStyleBackColor = true;
			// 
			// label12
			// 
			this.label12.AutoSize = true;
			this.label12.Location = new System.Drawing.Point(54, 36);
			this.label12.Name = "label12";
			this.label12.Size = new System.Drawing.Size(49, 13);
			this.label12.TabIndex = 11;
			this.label12.Text = "lblCliente";
			// 
			// label11
			// 
			this.label11.AutoSize = true;
			this.label11.Location = new System.Drawing.Point(96, 60);
			this.label11.Name = "label11";
			this.label11.Size = new System.Drawing.Size(73, 13);
			this.label11.TabIndex = 10;
			this.label11.Text = "lblDataPedido";
			// 
			// label10
			// 
			this.label10.AutoSize = true;
			this.label10.Location = new System.Drawing.Point(96, 139);
			this.label10.Name = "label10";
			this.label10.Size = new System.Drawing.Size(50, 13);
			this.label10.TabIndex = 9;
			this.label10.Text = "lblPedido";
			// 
			// checkBox2
			// 
			this.checkBox2.AutoSize = true;
			this.checkBox2.Location = new System.Drawing.Point(73, 85);
			this.checkBox2.Name = "checkBox2";
			this.checkBox2.Size = new System.Drawing.Size(15, 14);
			this.checkBox2.TabIndex = 8;
			this.checkBox2.UseVisualStyleBackColor = true;
			// 
			// checkBox1
			// 
			this.checkBox1.AutoSize = true;
			this.checkBox1.Location = new System.Drawing.Point(47, 109);
			this.checkBox1.Name = "checkBox1";
			this.checkBox1.Size = new System.Drawing.Size(15, 14);
			this.checkBox1.TabIndex = 7;
			this.checkBox1.UseVisualStyleBackColor = true;
			// 
			// textBox1
			// 
			this.textBox1.Location = new System.Drawing.Point(6, 190);
			this.textBox1.Multiline = true;
			this.textBox1.Name = "textBox1";
			this.textBox1.Size = new System.Drawing.Size(241, 157);
			this.textBox1.TabIndex = 6;
			// 
			// label9
			// 
			this.label9.AutoSize = true;
			this.label9.Location = new System.Drawing.Point(86, 171);
			this.label9.Name = "label9";
			this.label9.Size = new System.Drawing.Size(73, 13);
			this.label9.TabIndex = 5;
			this.label9.Text = "Observações:";
			// 
			// label8
			// 
			this.label8.AutoSize = true;
			this.label8.Location = new System.Drawing.Point(8, 139);
			this.label8.Name = "label8";
			this.label8.Size = new System.Drawing.Size(82, 13);
			this.label8.TabIndex = 4;
			this.label8.Text = "Tipo de Pedido:";
			// 
			// label7
			// 
			this.label7.AutoSize = true;
			this.label7.Location = new System.Drawing.Point(6, 109);
			this.label7.Name = "label7";
			this.label7.Size = new System.Drawing.Size(35, 13);
			this.label7.TabIndex = 3;
			this.label7.Text = "Pago:";
			// 
			// label5
			// 
			this.label5.AutoSize = true;
			this.label5.Location = new System.Drawing.Point(6, 85);
			this.label5.Name = "label5";
			this.label5.Size = new System.Drawing.Size(61, 13);
			this.label5.TabIndex = 2;
			this.label5.Text = "Levantado:";
			// 
			// label4
			// 
			this.label4.AutoSize = true;
			this.label4.Location = new System.Drawing.Point(6, 36);
			this.label4.Name = "label4";
			this.label4.Size = new System.Drawing.Size(42, 13);
			this.label4.TabIndex = 1;
			this.label4.Text = "Cliente:";
			// 
			// label3
			// 
			this.label3.AutoSize = true;
			this.label3.Location = new System.Drawing.Point(6, 60);
			this.label3.Name = "label3";
			this.label3.Size = new System.Drawing.Size(84, 13);
			this.label3.TabIndex = 0;
			this.label3.Text = "Data do Pedido:";
			// 
			// GerirPedidos
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.BackColor = System.Drawing.Color.WhiteSmoke;
			this.ClientSize = new System.Drawing.Size(892, 487);
			this.Controls.Add(this.lbPedidos);
			this.Controls.Add(this.groupBox1);
			this.Controls.Add(this.gpClientes);
			this.Controls.Add(this.panel1);
			this.Controls.Add(this.menuStrip);
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
			this.Name = "GerirPedidos";
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "GerirPedidos";
			this.Load += new System.EventHandler(this.GerirPedidos_Load);
			this.menuStrip.ResumeLayout(false);
			this.menuStrip.PerformLayout();
			this.panel1.ResumeLayout(false);
			this.groupBox1.ResumeLayout(false);
			this.groupBox1.PerformLayout();
			this.gpClientes.ResumeLayout(false);
			this.gpClientes.PerformLayout();
			this.ResumeLayout(false);
			this.PerformLayout();

		}

		#endregion

		private System.Windows.Forms.MenuStrip menuStrip;
		private System.Windows.Forms.ToolStripMenuItem menuToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem gerirClientesToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem gerirToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem gerirArranjosToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem gerirFornecedoresToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem sairToolStripMenuItem;
		private System.Windows.Forms.Panel panel1;
		private System.Windows.Forms.Button button1;
		private System.Windows.Forms.ListBox lbPedidos;
		private System.Windows.Forms.GroupBox groupBox1;
		private System.Windows.Forms.ComboBox cbTipoPedido;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.ComboBox cbCliente;
		private System.Windows.Forms.Button button2;
		private System.Windows.Forms.Label label6;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.TextBox textBox6;
		private System.Windows.Forms.GroupBox gpClientes;
		private System.Windows.Forms.Button button3;
		private System.Windows.Forms.Button button4;
		private System.Windows.Forms.Label label12;
		private System.Windows.Forms.Label label11;
		private System.Windows.Forms.Label label10;
		private System.Windows.Forms.CheckBox checkBox2;
		private System.Windows.Forms.CheckBox checkBox1;
		private System.Windows.Forms.TextBox textBox1;
		private System.Windows.Forms.Label label9;
		private System.Windows.Forms.Label label8;
		private System.Windows.Forms.Label label7;
		private System.Windows.Forms.Label label5;
		private System.Windows.Forms.Label label4;
		private System.Windows.Forms.Label label3;
		private System.Windows.Forms.ComboBox cbPeca;
		private System.Windows.Forms.Label label13;
	}
}