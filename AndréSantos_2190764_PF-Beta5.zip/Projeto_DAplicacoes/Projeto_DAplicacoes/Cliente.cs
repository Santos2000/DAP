﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Projeto_DAplicacoes
{
    using System;
    using System.Collections.Generic;

    public partial class Cliente
    {
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2214:DoNotCallOverridableMethodsInConstructors")]
        public Cliente()
        {
            this.Pedido = new HashSet<Pedido>();
        }

        public int Id { get; set; }
        public string Nome { get; set; }
        public string Morada { get; set; }
        public string Localidade { get; set; }
        public string Codigo_Postal { get; set; }
        public string Nif { get; set; }
        public string Telefone_Contacto { get; set; }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<Pedido> Pedido { get; set; }

        public override string ToString()
        {
            return string.Format("{0} ({1}) - {2}", Nome, Id, Nif);
        }

    }

    
}