﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Projeto_DAplicacoes
{
	public partial class GerirFornecedorMaterial : Form
	{
		private CRSMContainer bd;

		public GerirFornecedorMaterial()
		{
			InitializeComponent();
		}

		private void gerirClientesToolStripMenuItem_Click(object sender, EventArgs e)
		{
			this.Hide();
			GerirClientes form = new GerirClientes();
			form.Show();
		}

		private void gerirToolStripMenuItem_Click(object sender, EventArgs e)
		{
			this.Hide();
			GerirPedidos form = new GerirPedidos();
			form.Show();
		}

		private void sairToolStripMenuItem_Click(object sender, EventArgs e)
		{
			if (MessageBox.Show("Tem a certeza que pretende sair?", "Confirmar saída", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
			{
				Application.Exit();
			}
		}

		private void GerirFornecedorMaterial_Load(object sender, EventArgs e)
		{
			bd = new CRSMContainer();
			LerDados();
		}

		private void btAdicionarFornecedor_Click(object sender, EventArgs e)
		{
			Fornecedor fornecedor = new Fornecedor();
			fornecedor.Nome = tbNomeFornecedorAdd.Text;
			fornecedor.Morada = tbMoradaFornecedorAdd.Text;
			fornecedor.Localidade = tbLocalidadeFornecedorAdd.Text;
			fornecedor.CodigoPostal = tbCodPostalFornecedorAdd.Text;
			fornecedor.Nif = Convert.ToInt32(tbNifFornecedorAdd.Text);
			fornecedor.Telefone = Convert.ToInt32(tbTelefoneFornecedorAdd.Text);

			bd.FornecedorSet.Add(fornecedor);
			bd.SaveChanges();
			LerDados();

			LimpaTbAdicionarFornecedor();
		}

		private void lboxFornecedores_SelectedIndexChanged(object sender, EventArgs e)
		{
			
			Fornecedor selecionado = (Fornecedor)lboxFornecedores.SelectedItem;
			
			tbNomeFornecedorSelecionado.Text = selecionado.Nome;
			tbMoradaFornecedorSelecionado.Text = selecionado.Morada;
			tbLocalidadeFornecedorSelecionado.Text = selecionado.Localidade;
			tbCodPostalFornecedorSelecionado.Text = selecionado.CodigoPostal;

			/*Fim da aula: Converter nif e telefone para int para as tbs
			tbNifFornecedorSelecionado.Text = selecionado.Nif;
			tbTelefoneFornecedorSelecionado.Text = selecionado.Telefone;*/

		}

		private void LerDados()
		{
			lboxFornecedores.DataSource = bd.FornecedorSet.ToList<Fornecedor>();
		}

		private void LimpaTbAdicionarFornecedor()
		{
			tbNomeFornecedorAdd.Text = "";
			tbMoradaFornecedorAdd.Text = "";
			tbLocalidadeFornecedorAdd.Text = "";
			tbCodPostalFornecedorAdd.Text = "";
			tbNifFornecedorAdd.Text = "";
			tbTelefoneFornecedorAdd.Text = "";
		}
	}
}
