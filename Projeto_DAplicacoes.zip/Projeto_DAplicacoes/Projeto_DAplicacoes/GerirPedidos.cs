﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.Entity.Validation;

namespace Projeto_DAplicacoes
{
	public partial class GerirPedidos : Form
	{
		private CRSMContainer bd;
		public GerirPedidos()
		{
			InitializeComponent();
		}

		private void sairToolStripMenuItem_Click(object sender, EventArgs e)
		{
			if (MessageBox.Show("Tem a certeza que pretende sair?", "Confirmar saída", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
			{
				Application.Exit();
			}
		}

		private void gerirClientesToolStripMenuItem_Click(object sender, EventArgs e)
		{
			this.Hide();
			GerirClientes form = new GerirClientes();
			form.Show();
		}

		private void gerirFornecedoresToolStripMenuItem_Click(object sender, EventArgs e)
		{
			this.Hide();
			GerirFornecedorMaterial form = new GerirFornecedorMaterial();
			form.Show();
		}

		private void gerirArranjosToolStripMenuItem_Click(object sender, EventArgs e)
		{
			this.Hide();
			GerirArranjos form = new GerirArranjos();
			form.Show();
		}

		private void GerirPedidos_Load(object sender, EventArgs e)
		{
			bd = new CRSMContainer();
			LerDados();
			cbCorPeca.Items.Insert(0, "Amarelo");
			cbCorPeca.Items.Insert(1, "Azul");
			cbCorPeca.Items.Insert(2, "Branco");
			cbCorPeca.Items.Insert(3, "Cinzento");
			cbCorPeca.Items.Insert(4, "Laranja");
			cbCorPeca.Items.Insert(5, "Rosa");
			cbCorPeca.Items.Insert(6, "Vermelho");
			cbCorPeca.Items.Insert(7, "Vermelho");
			cbCorPeca.Items.Insert(8, "Violeta");
			cbCorPeca.Items.Insert(9, "Verde");
		}

		private void LerDados()
		{
			cbCliente.DataSource = bd.ClienteSet.ToList<Cliente>();
			cbPeca.DataSource = bd.PecaSet.ToList<Peca>();
			cbTipoPedido.DataSource = bd.ArranjoSet.ToList<Arranjo>();
			lboxPedidos.DataSource = bd.PedidoSet.ToList<Pedido>();
		}

		private void gerirToolStripMenuItem_Click(object sender, EventArgs e)
		{

		}

		private void btPedidosTabulados_Click(object sender, EventArgs e)
		{
			this.Hide();
			TabelaArranjos form = new TabelaArranjos();
			form.Show();
		}

		private void cboxPedidoNaoTabelado_CheckedChanged(object sender, EventArgs e)
		{
			if(cboxPedidoNaoTabelado.Checked == true)
			{
				tbPedidoNaoTabelado.Enabled = true;
				cbTipoPedido.Enabled = false;
				cbTipoPedido.Text = "";
			}
			else
			{
				tbPedidoNaoTabelado.Enabled = false;
				cbTipoPedido.Enabled = true;
			}
			
		}

		private void btAdicionarPedido_Click(object sender, EventArgs e)
		{
			Pedido pedido = new Pedido();
			pedido.DataPedido = DateTime.Now;
			if (cboxPedidoNaoTabelado.Checked == true)
			{
				pedido.Pago = false;
				pedido.TipoPedido = "Não tabelado";
			}
			else
			{
				pedido.Pago = true;
				pedido.TipoPedido = "Tabelado";
			}
			pedido.Levantado = false;
			pedido.Observacoes = tbObservacoes.Text;
			Cliente selecionado = (Cliente)cbCliente.SelectedItem;
			pedido.ClienteId = selecionado.Id;
			pedido.ClienteId1 = selecionado.Id; 
			pedido.

			PedidoTabelado novo = new PedidoTabelado();
			novo.Id = pedido.Id;

			Trabalho trabalho = new Trabalho();
			trabalho.DescricaoPeca = tbDescricaoPeca.Text;
			trabalho.CorPeca = cbCorPeca.Text;

			if ((cbTipoPedido.Text == "Colocar Fecho") && (cbPeca.Text == "Casaco"))
			{
				trabalho.ValorPago = 10;
			}
			else if ((cbTipoPedido.Text == "Colocar Fecho") && (cbPeca.Text != "Casaco"))
			{
				trabalho.ValorPago = 7;
			}
			else
			{
				trabalho.ValorPago = 5;
			}

			trabalho.Pago = Convert.ToString(pedido.Pago);
			trabalho.Levantado = "false";
			trabalho.Observacoes = tbObservacoes.Text;
			trabalho.DevolucaoId = 2;

			Peca selecionada = (Peca)cbPeca.SelectedItem;
			trabalho.PecaArranjoPecaId = selecionada.Id;

			Arranjo arranjo = (Arranjo)cbTipoPedido.SelectedItem; 
			trabalho.PecaArranjoArranjoId = arranjo.Id;
			
			bd.PedidoSet.Add(pedido);
			bd.SaveChanges();
			PedidoTabelado novopedidoTabelado = new PedidoTabelado();

			using (var context = new CRSMContainer())
			{
				var blog = context.PedidoSet.OrderByDescending(b => b.Id).FirstOrDefault();
				novopedidoTabelado.Id = Convert.ToInt32(blog.Id);
				
				trabalho.PedidoTabeladoId = Convert.ToInt32(blog.Id);
				
			}

			
			


			bd.TrabalhoSet.Add(trabalho);
			bd.SaveChanges();
			
			
			LerDados();


		}
	}
}
