﻿namespace Projeto_DAplicacoes
{
	partial class GerirArranjos
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.menuStrip = new System.Windows.Forms.MenuStrip();
			this.menuToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.gerirClientesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.gerirToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.gerirArranjosToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.gerirFornecedoresToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.sairToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.btVerificarArranjosTabelados = new System.Windows.Forms.Button();
			this.cbTipoArranjo = new System.Windows.Forms.ComboBox();
			this.label1 = new System.Windows.Forms.Label();
			this.label2 = new System.Windows.Forms.Label();
			this.cbPeca = new System.Windows.Forms.ComboBox();
			this.label3 = new System.Windows.Forms.Label();
			this.cbCorPeca = new System.Windows.Forms.ComboBox();
			this.tbDescricaoPeca = new System.Windows.Forms.TextBox();
			this.label4 = new System.Windows.Forms.Label();
			this.btConfirmarArranjo = new System.Windows.Forms.Button();
			this.label5 = new System.Windows.Forms.Label();
			this.groupBox1 = new System.Windows.Forms.GroupBox();
			this.label6 = new System.Windows.Forms.Label();
			this.cbCliente = new System.Windows.Forms.ComboBox();
			this.lbArranjos = new System.Windows.Forms.ListBox();
			this.label7 = new System.Windows.Forms.Label();
			this.menuStrip.SuspendLayout();
			this.groupBox1.SuspendLayout();
			this.SuspendLayout();
			// 
			// menuStrip
			// 
			this.menuStrip.BackColor = System.Drawing.Color.LightGray;
			this.menuStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.menuToolStripMenuItem});
			this.menuStrip.Location = new System.Drawing.Point(0, 0);
			this.menuStrip.Name = "menuStrip";
			this.menuStrip.Size = new System.Drawing.Size(936, 24);
			this.menuStrip.TabIndex = 3;
			this.menuStrip.Text = "menuStrip1";
			// 
			// menuToolStripMenuItem
			// 
			this.menuToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.gerirClientesToolStripMenuItem,
            this.gerirToolStripMenuItem,
            this.gerirArranjosToolStripMenuItem,
            this.gerirFornecedoresToolStripMenuItem,
            this.sairToolStripMenuItem});
			this.menuToolStripMenuItem.Name = "menuToolStripMenuItem";
			this.menuToolStripMenuItem.Size = new System.Drawing.Size(50, 20);
			this.menuToolStripMenuItem.Text = "Menu";
			// 
			// gerirClientesToolStripMenuItem
			// 
			this.gerirClientesToolStripMenuItem.Name = "gerirClientesToolStripMenuItem";
			this.gerirClientesToolStripMenuItem.Size = new System.Drawing.Size(173, 22);
			this.gerirClientesToolStripMenuItem.Text = "Gerir Clientes";
			this.gerirClientesToolStripMenuItem.Click += new System.EventHandler(this.gerirClientesToolStripMenuItem_Click);
			// 
			// gerirToolStripMenuItem
			// 
			this.gerirToolStripMenuItem.Name = "gerirToolStripMenuItem";
			this.gerirToolStripMenuItem.Size = new System.Drawing.Size(173, 22);
			this.gerirToolStripMenuItem.Text = "Gerir Pedidos";
			this.gerirToolStripMenuItem.Click += new System.EventHandler(this.gerirToolStripMenuItem_Click);
			// 
			// gerirArranjosToolStripMenuItem
			// 
			this.gerirArranjosToolStripMenuItem.Name = "gerirArranjosToolStripMenuItem";
			this.gerirArranjosToolStripMenuItem.Size = new System.Drawing.Size(173, 22);
			this.gerirArranjosToolStripMenuItem.Text = "Gerir Arranjos";
			this.gerirArranjosToolStripMenuItem.Click += new System.EventHandler(this.gerirArranjosToolStripMenuItem_Click);
			// 
			// gerirFornecedoresToolStripMenuItem
			// 
			this.gerirFornecedoresToolStripMenuItem.Name = "gerirFornecedoresToolStripMenuItem";
			this.gerirFornecedoresToolStripMenuItem.Size = new System.Drawing.Size(173, 22);
			this.gerirFornecedoresToolStripMenuItem.Text = "Gerir Fornecedores";
			this.gerirFornecedoresToolStripMenuItem.Click += new System.EventHandler(this.gerirFornecedoresToolStripMenuItem_Click);
			// 
			// sairToolStripMenuItem
			// 
			this.sairToolStripMenuItem.Name = "sairToolStripMenuItem";
			this.sairToolStripMenuItem.Size = new System.Drawing.Size(173, 22);
			this.sairToolStripMenuItem.Text = "Sair";
			this.sairToolStripMenuItem.Click += new System.EventHandler(this.sairToolStripMenuItem_Click);
			// 
			// btVerificarArranjosTabelados
			// 
			this.btVerificarArranjosTabelados.Location = new System.Drawing.Point(33, 50);
			this.btVerificarArranjosTabelados.Name = "btVerificarArranjosTabelados";
			this.btVerificarArranjosTabelados.Size = new System.Drawing.Size(100, 39);
			this.btVerificarArranjosTabelados.TabIndex = 4;
			this.btVerificarArranjosTabelados.Text = "Verificar tabela de arranjos";
			this.btVerificarArranjosTabelados.UseVisualStyleBackColor = true;
			this.btVerificarArranjosTabelados.Click += new System.EventHandler(this.btVerificarArranjosTabelados_Click);
			// 
			// cbTipoArranjo
			// 
			this.cbTipoArranjo.FormattingEnabled = true;
			this.cbTipoArranjo.Location = new System.Drawing.Point(5, 110);
			this.cbTipoArranjo.Name = "cbTipoArranjo";
			this.cbTipoArranjo.Size = new System.Drawing.Size(285, 21);
			this.cbTipoArranjo.TabIndex = 5;
			// 
			// label1
			// 
			this.label1.AutoSize = true;
			this.label1.Location = new System.Drawing.Point(104, 94);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(81, 13);
			this.label1.TabIndex = 6;
			this.label1.Text = "Tipo de arranjo:";
			// 
			// label2
			// 
			this.label2.AutoSize = true;
			this.label2.Location = new System.Drawing.Point(129, 149);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(35, 13);
			this.label2.TabIndex = 8;
			this.label2.Text = "Peça:";
			// 
			// cbPeca
			// 
			this.cbPeca.FormattingEnabled = true;
			this.cbPeca.Location = new System.Drawing.Point(5, 165);
			this.cbPeca.Name = "cbPeca";
			this.cbPeca.Size = new System.Drawing.Size(285, 21);
			this.cbPeca.TabIndex = 7;
			// 
			// label3
			// 
			this.label3.AutoSize = true;
			this.label3.Location = new System.Drawing.Point(117, 205);
			this.label3.Name = "label3";
			this.label3.Size = new System.Drawing.Size(68, 13);
			this.label3.TabIndex = 10;
			this.label3.Text = "Cor da peça:";
			// 
			// cbCorPeca
			// 
			this.cbCorPeca.FormattingEnabled = true;
			this.cbCorPeca.Location = new System.Drawing.Point(5, 221);
			this.cbCorPeca.Name = "cbCorPeca";
			this.cbCorPeca.Size = new System.Drawing.Size(285, 21);
			this.cbCorPeca.TabIndex = 9;
			// 
			// tbDescricaoPeca
			// 
			this.tbDescricaoPeca.Location = new System.Drawing.Point(6, 310);
			this.tbDescricaoPeca.MaxLength = 200;
			this.tbDescricaoPeca.Multiline = true;
			this.tbDescricaoPeca.Name = "tbDescricaoPeca";
			this.tbDescricaoPeca.Size = new System.Drawing.Size(285, 93);
			this.tbDescricaoPeca.TabIndex = 11;
			// 
			// label4
			// 
			this.label4.AutoSize = true;
			this.label4.Location = new System.Drawing.Point(6, 294);
			this.label4.Name = "label4";
			this.label4.Size = new System.Drawing.Size(129, 13);
			this.label4.TabIndex = 12;
			this.label4.Text = "Breve descrição da peça:";
			// 
			// btConfirmarArranjo
			// 
			this.btConfirmarArranjo.Location = new System.Drawing.Point(12, 526);
			this.btConfirmarArranjo.Name = "btConfirmarArranjo";
			this.btConfirmarArranjo.Size = new System.Drawing.Size(100, 39);
			this.btConfirmarArranjo.TabIndex = 13;
			this.btConfirmarArranjo.Text = "Confirmar Arranjo";
			this.btConfirmarArranjo.UseVisualStyleBackColor = true;
			this.btConfirmarArranjo.Click += new System.EventHandler(this.btConfirmarArranjo_Click);
			// 
			// label5
			// 
			this.label5.AutoSize = true;
			this.label5.Location = new System.Drawing.Point(12, 34);
			this.label5.Name = "label5";
			this.label5.Size = new System.Drawing.Size(154, 13);
			this.label5.TabIndex = 14;
			this.label5.Text = "Tipos de arranjos que fazemos:";
			// 
			// groupBox1
			// 
			this.groupBox1.Controls.Add(this.label6);
			this.groupBox1.Controls.Add(this.cbCliente);
			this.groupBox1.Controls.Add(this.label1);
			this.groupBox1.Controls.Add(this.cbTipoArranjo);
			this.groupBox1.Controls.Add(this.cbPeca);
			this.groupBox1.Controls.Add(this.label2);
			this.groupBox1.Controls.Add(this.label4);
			this.groupBox1.Controls.Add(this.cbCorPeca);
			this.groupBox1.Controls.Add(this.tbDescricaoPeca);
			this.groupBox1.Controls.Add(this.label3);
			this.groupBox1.Location = new System.Drawing.Point(12, 95);
			this.groupBox1.Name = "groupBox1";
			this.groupBox1.Size = new System.Drawing.Size(297, 409);
			this.groupBox1.TabIndex = 27;
			this.groupBox1.TabStop = false;
			this.groupBox1.Text = "Resgistar Arranjo";
			// 
			// label6
			// 
			this.label6.AutoSize = true;
			this.label6.Location = new System.Drawing.Point(129, 39);
			this.label6.Name = "label6";
			this.label6.Size = new System.Drawing.Size(42, 13);
			this.label6.TabIndex = 14;
			this.label6.Text = "Cliente:";
			// 
			// cbCliente
			// 
			this.cbCliente.FormattingEnabled = true;
			this.cbCliente.Location = new System.Drawing.Point(5, 55);
			this.cbCliente.Name = "cbCliente";
			this.cbCliente.Size = new System.Drawing.Size(285, 21);
			this.cbCliente.TabIndex = 13;
			// 
			// lbArranjos
			// 
			this.lbArranjos.FormattingEnabled = true;
			this.lbArranjos.Location = new System.Drawing.Point(315, 60);
			this.lbArranjos.Name = "lbArranjos";
			this.lbArranjos.Size = new System.Drawing.Size(328, 446);
			this.lbArranjos.TabIndex = 28;
			// 
			// label7
			// 
			this.label7.AutoSize = true;
			this.label7.Location = new System.Drawing.Point(312, 34);
			this.label7.Name = "label7";
			this.label7.Size = new System.Drawing.Size(88, 13);
			this.label7.TabIndex = 29;
			this.label7.Text = "Lista de Arranjos:";
			// 
			// GerirArranjos
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(936, 577);
			this.Controls.Add(this.label7);
			this.Controls.Add(this.lbArranjos);
			this.Controls.Add(this.groupBox1);
			this.Controls.Add(this.label5);
			this.Controls.Add(this.btConfirmarArranjo);
			this.Controls.Add(this.btVerificarArranjosTabelados);
			this.Controls.Add(this.menuStrip);
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
			this.Name = "GerirArranjos";
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "GerirArranjos";
			this.Load += new System.EventHandler(this.GerirArranjos_Load);
			this.menuStrip.ResumeLayout(false);
			this.menuStrip.PerformLayout();
			this.groupBox1.ResumeLayout(false);
			this.groupBox1.PerformLayout();
			this.ResumeLayout(false);
			this.PerformLayout();

		}

		#endregion

		private System.Windows.Forms.MenuStrip menuStrip;
		private System.Windows.Forms.ToolStripMenuItem menuToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem gerirClientesToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem gerirToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem gerirArranjosToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem gerirFornecedoresToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem sairToolStripMenuItem;
		private System.Windows.Forms.Button btVerificarArranjosTabelados;
		private System.Windows.Forms.ComboBox cbTipoArranjo;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.ComboBox cbPeca;
		private System.Windows.Forms.Label label3;
		private System.Windows.Forms.ComboBox cbCorPeca;
		private System.Windows.Forms.TextBox tbDescricaoPeca;
		private System.Windows.Forms.Label label4;
		private System.Windows.Forms.Button btConfirmarArranjo;
		private System.Windows.Forms.Label label5;
		private System.Windows.Forms.GroupBox groupBox1;
		private System.Windows.Forms.Label label6;
		private System.Windows.Forms.ComboBox cbCliente;
		private System.Windows.Forms.ListBox lbArranjos;
		private System.Windows.Forms.Label label7;
	}
}