﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Projeto_DAplicacoes
{
	public partial class TabelaArranjos : Form
	{
		public TabelaArranjos()
		{
			InitializeComponent();
		}

		private void btSair_Click(object sender, EventArgs e)
		{
			this.Hide();
			GerirArranjos form = new GerirArranjos();
			form.Show();
		}
	}
}
