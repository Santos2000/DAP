﻿namespace Projeto_DAplicacoes
{
	partial class GerirPedidos
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(GerirPedidos));
			this.menuStrip = new System.Windows.Forms.MenuStrip();
			this.menuToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.gerirClientesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.gerirToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.gerirArranjosToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.gerirFornecedoresToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.sairToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.panel1 = new System.Windows.Forms.Panel();
			this.button1 = new System.Windows.Forms.Button();
			this.lboxPedidos = new System.Windows.Forms.ListBox();
			this.groupBox1 = new System.Windows.Forms.GroupBox();
			this.cbPeca = new System.Windows.Forms.ComboBox();
			this.label13 = new System.Windows.Forms.Label();
			this.cbTipoPedido = new System.Windows.Forms.ComboBox();
			this.label2 = new System.Windows.Forms.Label();
			this.cbCliente = new System.Windows.Forms.ComboBox();
			this.btAdicionarPedido = new System.Windows.Forms.Button();
			this.label6 = new System.Windows.Forms.Label();
			this.label1 = new System.Windows.Forms.Label();
			this.tbObservacoes = new System.Windows.Forms.TextBox();
			this.gpClientes = new System.Windows.Forms.GroupBox();
			this.btAtualizarPedido = new System.Windows.Forms.Button();
			this.btApagarPedido = new System.Windows.Forms.Button();
			this.label12 = new System.Windows.Forms.Label();
			this.label11 = new System.Windows.Forms.Label();
			this.label10 = new System.Windows.Forms.Label();
			this.checkBox2 = new System.Windows.Forms.CheckBox();
			this.checkBox1 = new System.Windows.Forms.CheckBox();
			this.textBox1 = new System.Windows.Forms.TextBox();
			this.label9 = new System.Windows.Forms.Label();
			this.label8 = new System.Windows.Forms.Label();
			this.label7 = new System.Windows.Forms.Label();
			this.label5 = new System.Windows.Forms.Label();
			this.label4 = new System.Windows.Forms.Label();
			this.label3 = new System.Windows.Forms.Label();
			this.btPedidosTabulados = new System.Windows.Forms.Button();
			this.cboxPedidoNaoTabelado = new System.Windows.Forms.CheckBox();
			this.tbPedidoNaoTabelado = new System.Windows.Forms.TextBox();
			this.cbCorPeca = new System.Windows.Forms.ComboBox();
			this.label14 = new System.Windows.Forms.Label();
			this.label15 = new System.Windows.Forms.Label();
			this.tbDescricaoPeca = new System.Windows.Forms.TextBox();
			this.menuStrip.SuspendLayout();
			this.panel1.SuspendLayout();
			this.groupBox1.SuspendLayout();
			this.gpClientes.SuspendLayout();
			this.SuspendLayout();
			// 
			// menuStrip
			// 
			this.menuStrip.BackColor = System.Drawing.Color.LightGray;
			this.menuStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.menuToolStripMenuItem});
			this.menuStrip.Location = new System.Drawing.Point(0, 0);
			this.menuStrip.Name = "menuStrip";
			this.menuStrip.Size = new System.Drawing.Size(999, 24);
			this.menuStrip.TabIndex = 2;
			this.menuStrip.Text = "menuStrip1";
			// 
			// menuToolStripMenuItem
			// 
			this.menuToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.gerirClientesToolStripMenuItem,
            this.gerirToolStripMenuItem,
            this.gerirArranjosToolStripMenuItem,
            this.gerirFornecedoresToolStripMenuItem,
            this.sairToolStripMenuItem});
			this.menuToolStripMenuItem.Name = "menuToolStripMenuItem";
			this.menuToolStripMenuItem.Size = new System.Drawing.Size(50, 20);
			this.menuToolStripMenuItem.Text = "Menu";
			// 
			// gerirClientesToolStripMenuItem
			// 
			this.gerirClientesToolStripMenuItem.Name = "gerirClientesToolStripMenuItem";
			this.gerirClientesToolStripMenuItem.Size = new System.Drawing.Size(173, 22);
			this.gerirClientesToolStripMenuItem.Text = "Gerir Clientes";
			this.gerirClientesToolStripMenuItem.Click += new System.EventHandler(this.gerirClientesToolStripMenuItem_Click);
			// 
			// gerirToolStripMenuItem
			// 
			this.gerirToolStripMenuItem.Name = "gerirToolStripMenuItem";
			this.gerirToolStripMenuItem.Size = new System.Drawing.Size(173, 22);
			this.gerirToolStripMenuItem.Text = "Gerir Pedidos";
			this.gerirToolStripMenuItem.Click += new System.EventHandler(this.gerirToolStripMenuItem_Click);
			// 
			// gerirArranjosToolStripMenuItem
			// 
			this.gerirArranjosToolStripMenuItem.Name = "gerirArranjosToolStripMenuItem";
			this.gerirArranjosToolStripMenuItem.Size = new System.Drawing.Size(173, 22);
			this.gerirArranjosToolStripMenuItem.Text = "Gerir Arranjos";
			this.gerirArranjosToolStripMenuItem.Click += new System.EventHandler(this.gerirArranjosToolStripMenuItem_Click);
			// 
			// gerirFornecedoresToolStripMenuItem
			// 
			this.gerirFornecedoresToolStripMenuItem.Name = "gerirFornecedoresToolStripMenuItem";
			this.gerirFornecedoresToolStripMenuItem.Size = new System.Drawing.Size(173, 22);
			this.gerirFornecedoresToolStripMenuItem.Text = "Gerir Fornecedores";
			this.gerirFornecedoresToolStripMenuItem.Click += new System.EventHandler(this.gerirFornecedoresToolStripMenuItem_Click);
			// 
			// sairToolStripMenuItem
			// 
			this.sairToolStripMenuItem.Name = "sairToolStripMenuItem";
			this.sairToolStripMenuItem.Size = new System.Drawing.Size(173, 22);
			this.sairToolStripMenuItem.Text = "Sair";
			this.sairToolStripMenuItem.Click += new System.EventHandler(this.sairToolStripMenuItem_Click);
			// 
			// panel1
			// 
			this.panel1.BackColor = System.Drawing.Color.LightGray;
			this.panel1.Controls.Add(this.button1);
			this.panel1.Dock = System.Windows.Forms.DockStyle.Bottom;
			this.panel1.Location = new System.Drawing.Point(0, 622);
			this.panel1.Name = "panel1";
			this.panel1.Size = new System.Drawing.Size(999, 38);
			this.panel1.TabIndex = 3;
			// 
			// button1
			// 
			this.button1.BackColor = System.Drawing.Color.Transparent;
			this.button1.Image = ((System.Drawing.Image)(resources.GetObject("button1.Image")));
			this.button1.Location = new System.Drawing.Point(0, 0);
			this.button1.Name = "button1";
			this.button1.Size = new System.Drawing.Size(45, 38);
			this.button1.TabIndex = 2;
			this.button1.UseVisualStyleBackColor = false;
			// 
			// lboxPedidos
			// 
			this.lboxPedidos.FormattingEnabled = true;
			this.lboxPedidos.Location = new System.Drawing.Point(330, 29);
			this.lboxPedidos.Name = "lboxPedidos";
			this.lboxPedidos.Size = new System.Drawing.Size(364, 407);
			this.lboxPedidos.TabIndex = 29;
			// 
			// groupBox1
			// 
			this.groupBox1.Controls.Add(this.label15);
			this.groupBox1.Controls.Add(this.tbDescricaoPeca);
			this.groupBox1.Controls.Add(this.cbCorPeca);
			this.groupBox1.Controls.Add(this.label14);
			this.groupBox1.Controls.Add(this.tbPedidoNaoTabelado);
			this.groupBox1.Controls.Add(this.cboxPedidoNaoTabelado);
			this.groupBox1.Controls.Add(this.cbPeca);
			this.groupBox1.Controls.Add(this.label13);
			this.groupBox1.Controls.Add(this.cbTipoPedido);
			this.groupBox1.Controls.Add(this.label2);
			this.groupBox1.Controls.Add(this.cbCliente);
			this.groupBox1.Controls.Add(this.btAdicionarPedido);
			this.groupBox1.Controls.Add(this.label6);
			this.groupBox1.Controls.Add(this.label1);
			this.groupBox1.Controls.Add(this.tbObservacoes);
			this.groupBox1.Location = new System.Drawing.Point(12, 98);
			this.groupBox1.Name = "groupBox1";
			this.groupBox1.Size = new System.Drawing.Size(297, 518);
			this.groupBox1.TabIndex = 26;
			this.groupBox1.TabStop = false;
			this.groupBox1.Text = "Resgistar Pedido";
			// 
			// cbPeca
			// 
			this.cbPeca.FormattingEnabled = true;
			this.cbPeca.Location = new System.Drawing.Point(4, 257);
			this.cbPeca.Name = "cbPeca";
			this.cbPeca.Size = new System.Drawing.Size(286, 21);
			this.cbPeca.TabIndex = 20;
			// 
			// label13
			// 
			this.label13.AutoSize = true;
			this.label13.Location = new System.Drawing.Point(130, 241);
			this.label13.Name = "label13";
			this.label13.Size = new System.Drawing.Size(35, 13);
			this.label13.TabIndex = 19;
			this.label13.Text = "Peça:";
			// 
			// cbTipoPedido
			// 
			this.cbTipoPedido.FormattingEnabled = true;
			this.cbTipoPedido.Location = new System.Drawing.Point(5, 77);
			this.cbTipoPedido.Name = "cbTipoPedido";
			this.cbTipoPedido.Size = new System.Drawing.Size(286, 21);
			this.cbTipoPedido.TabIndex = 18;
			// 
			// label2
			// 
			this.label2.AutoSize = true;
			this.label2.Location = new System.Drawing.Point(113, 61);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(82, 13);
			this.label2.TabIndex = 17;
			this.label2.Text = "Tipo de Pedido:";
			// 
			// cbCliente
			// 
			this.cbCliente.FormattingEnabled = true;
			this.cbCliente.Location = new System.Drawing.Point(6, 28);
			this.cbCliente.Name = "cbCliente";
			this.cbCliente.Size = new System.Drawing.Size(284, 21);
			this.cbCliente.TabIndex = 16;
			// 
			// btAdicionarPedido
			// 
			this.btAdicionarPedido.Location = new System.Drawing.Point(6, 489);
			this.btAdicionarPedido.Name = "btAdicionarPedido";
			this.btAdicionarPedido.Size = new System.Drawing.Size(279, 23);
			this.btAdicionarPedido.TabIndex = 2;
			this.btAdicionarPedido.Text = "Adicionar pedido";
			this.btAdicionarPedido.UseVisualStyleBackColor = true;
			this.btAdicionarPedido.Click += new System.EventHandler(this.btAdicionarPedido_Click);
			// 
			// label6
			// 
			this.label6.AutoSize = true;
			this.label6.Location = new System.Drawing.Point(111, 153);
			this.label6.Name = "label6";
			this.label6.Size = new System.Drawing.Size(73, 13);
			this.label6.TabIndex = 13;
			this.label6.Text = "Observações:";
			// 
			// label1
			// 
			this.label1.AutoSize = true;
			this.label1.Location = new System.Drawing.Point(132, 12);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(42, 13);
			this.label1.TabIndex = 3;
			this.label1.Text = "Cliente:";
			// 
			// tbObservacoes
			// 
			this.tbObservacoes.Location = new System.Drawing.Point(3, 169);
			this.tbObservacoes.Multiline = true;
			this.tbObservacoes.Name = "tbObservacoes";
			this.tbObservacoes.Size = new System.Drawing.Size(285, 59);
			this.tbObservacoes.TabIndex = 12;
			// 
			// gpClientes
			// 
			this.gpClientes.Controls.Add(this.btAtualizarPedido);
			this.gpClientes.Controls.Add(this.btApagarPedido);
			this.gpClientes.Controls.Add(this.label12);
			this.gpClientes.Controls.Add(this.label11);
			this.gpClientes.Controls.Add(this.label10);
			this.gpClientes.Controls.Add(this.checkBox2);
			this.gpClientes.Controls.Add(this.checkBox1);
			this.gpClientes.Controls.Add(this.textBox1);
			this.gpClientes.Controls.Add(this.label9);
			this.gpClientes.Controls.Add(this.label8);
			this.gpClientes.Controls.Add(this.label7);
			this.gpClientes.Controls.Add(this.label5);
			this.gpClientes.Controls.Add(this.label4);
			this.gpClientes.Controls.Add(this.label3);
			this.gpClientes.Location = new System.Drawing.Point(712, 29);
			this.gpClientes.Name = "gpClientes";
			this.gpClientes.Size = new System.Drawing.Size(256, 412);
			this.gpClientes.TabIndex = 28;
			this.gpClientes.TabStop = false;
			this.gpClientes.Text = "Dados do Pedido";
			// 
			// btAtualizarPedido
			// 
			this.btAtualizarPedido.Location = new System.Drawing.Point(135, 358);
			this.btAtualizarPedido.Name = "btAtualizarPedido";
			this.btAtualizarPedido.Size = new System.Drawing.Size(112, 49);
			this.btAtualizarPedido.TabIndex = 13;
			this.btAtualizarPedido.Text = "Atualizar Pedido";
			this.btAtualizarPedido.UseVisualStyleBackColor = true;
			// 
			// btApagarPedido
			// 
			this.btApagarPedido.Location = new System.Drawing.Point(9, 358);
			this.btApagarPedido.Name = "btApagarPedido";
			this.btApagarPedido.Size = new System.Drawing.Size(112, 49);
			this.btApagarPedido.TabIndex = 12;
			this.btApagarPedido.Text = "Apagar Pedido";
			this.btApagarPedido.UseVisualStyleBackColor = true;
			// 
			// label12
			// 
			this.label12.AutoSize = true;
			this.label12.Location = new System.Drawing.Point(54, 36);
			this.label12.Name = "label12";
			this.label12.Size = new System.Drawing.Size(49, 13);
			this.label12.TabIndex = 11;
			this.label12.Text = "lblCliente";
			// 
			// label11
			// 
			this.label11.AutoSize = true;
			this.label11.Location = new System.Drawing.Point(96, 60);
			this.label11.Name = "label11";
			this.label11.Size = new System.Drawing.Size(73, 13);
			this.label11.TabIndex = 10;
			this.label11.Text = "lblDataPedido";
			// 
			// label10
			// 
			this.label10.AutoSize = true;
			this.label10.Location = new System.Drawing.Point(96, 139);
			this.label10.Name = "label10";
			this.label10.Size = new System.Drawing.Size(50, 13);
			this.label10.TabIndex = 9;
			this.label10.Text = "lblPedido";
			// 
			// checkBox2
			// 
			this.checkBox2.AutoSize = true;
			this.checkBox2.Location = new System.Drawing.Point(73, 85);
			this.checkBox2.Name = "checkBox2";
			this.checkBox2.Size = new System.Drawing.Size(15, 14);
			this.checkBox2.TabIndex = 8;
			this.checkBox2.UseVisualStyleBackColor = true;
			// 
			// checkBox1
			// 
			this.checkBox1.AutoSize = true;
			this.checkBox1.Location = new System.Drawing.Point(47, 109);
			this.checkBox1.Name = "checkBox1";
			this.checkBox1.Size = new System.Drawing.Size(15, 14);
			this.checkBox1.TabIndex = 7;
			this.checkBox1.UseVisualStyleBackColor = true;
			// 
			// textBox1
			// 
			this.textBox1.Location = new System.Drawing.Point(6, 190);
			this.textBox1.Multiline = true;
			this.textBox1.Name = "textBox1";
			this.textBox1.Size = new System.Drawing.Size(241, 157);
			this.textBox1.TabIndex = 6;
			// 
			// label9
			// 
			this.label9.AutoSize = true;
			this.label9.Location = new System.Drawing.Point(86, 171);
			this.label9.Name = "label9";
			this.label9.Size = new System.Drawing.Size(73, 13);
			this.label9.TabIndex = 5;
			this.label9.Text = "Observações:";
			// 
			// label8
			// 
			this.label8.AutoSize = true;
			this.label8.Location = new System.Drawing.Point(8, 139);
			this.label8.Name = "label8";
			this.label8.Size = new System.Drawing.Size(82, 13);
			this.label8.TabIndex = 4;
			this.label8.Text = "Tipo de Pedido:";
			// 
			// label7
			// 
			this.label7.AutoSize = true;
			this.label7.Location = new System.Drawing.Point(6, 109);
			this.label7.Name = "label7";
			this.label7.Size = new System.Drawing.Size(35, 13);
			this.label7.TabIndex = 3;
			this.label7.Text = "Pago:";
			// 
			// label5
			// 
			this.label5.AutoSize = true;
			this.label5.Location = new System.Drawing.Point(6, 85);
			this.label5.Name = "label5";
			this.label5.Size = new System.Drawing.Size(61, 13);
			this.label5.TabIndex = 2;
			this.label5.Text = "Levantado:";
			// 
			// label4
			// 
			this.label4.AutoSize = true;
			this.label4.Location = new System.Drawing.Point(6, 36);
			this.label4.Name = "label4";
			this.label4.Size = new System.Drawing.Size(42, 13);
			this.label4.TabIndex = 1;
			this.label4.Text = "Cliente:";
			// 
			// label3
			// 
			this.label3.AutoSize = true;
			this.label3.Location = new System.Drawing.Point(6, 60);
			this.label3.Name = "label3";
			this.label3.Size = new System.Drawing.Size(84, 13);
			this.label3.TabIndex = 0;
			this.label3.Text = "Data do Pedido:";
			// 
			// btPedidosTabulados
			// 
			this.btPedidosTabulados.Location = new System.Drawing.Point(45, 29);
			this.btPedidosTabulados.Name = "btPedidosTabulados";
			this.btPedidosTabulados.Size = new System.Drawing.Size(204, 20);
			this.btPedidosTabulados.TabIndex = 30;
			this.btPedidosTabulados.Text = "Verificar Pedidos Tabelados";
			this.btPedidosTabulados.UseVisualStyleBackColor = true;
			this.btPedidosTabulados.Click += new System.EventHandler(this.btPedidosTabulados_Click);
			// 
			// cboxPedidoNaoTabelado
			// 
			this.cboxPedidoNaoTabelado.AutoSize = true;
			this.cboxPedidoNaoTabelado.Location = new System.Drawing.Point(3, 104);
			this.cboxPedidoNaoTabelado.Name = "cboxPedidoNaoTabelado";
			this.cboxPedidoNaoTabelado.Size = new System.Drawing.Size(287, 17);
			this.cboxPedidoNaoTabelado.TabIndex = 21;
			this.cboxPedidoNaoTabelado.Text = "Pedido não tabelado, descreva abaixo o tipo de pedido";
			this.cboxPedidoNaoTabelado.UseVisualStyleBackColor = true;
			this.cboxPedidoNaoTabelado.CheckedChanged += new System.EventHandler(this.cboxPedidoNaoTabelado_CheckedChanged);
			// 
			// tbPedidoNaoTabelado
			// 
			this.tbPedidoNaoTabelado.Enabled = false;
			this.tbPedidoNaoTabelado.Location = new System.Drawing.Point(3, 127);
			this.tbPedidoNaoTabelado.Name = "tbPedidoNaoTabelado";
			this.tbPedidoNaoTabelado.Size = new System.Drawing.Size(284, 20);
			this.tbPedidoNaoTabelado.TabIndex = 22;
			// 
			// cbCorPeca
			// 
			this.cbCorPeca.FormattingEnabled = true;
			this.cbCorPeca.Location = new System.Drawing.Point(7, 310);
			this.cbCorPeca.Name = "cbCorPeca";
			this.cbCorPeca.Size = new System.Drawing.Size(285, 21);
			this.cbCorPeca.TabIndex = 23;
			// 
			// label14
			// 
			this.label14.AutoSize = true;
			this.label14.Location = new System.Drawing.Point(119, 294);
			this.label14.Name = "label14";
			this.label14.Size = new System.Drawing.Size(68, 13);
			this.label14.TabIndex = 24;
			this.label14.Text = "Cor da peça:";
			// 
			// label15
			// 
			this.label15.AutoSize = true;
			this.label15.Location = new System.Drawing.Point(81, 334);
			this.label15.Name = "label15";
			this.label15.Size = new System.Drawing.Size(129, 13);
			this.label15.TabIndex = 26;
			this.label15.Text = "Breve descrição da peça:";
			// 
			// tbDescricaoPeca
			// 
			this.tbDescricaoPeca.Location = new System.Drawing.Point(6, 350);
			this.tbDescricaoPeca.MaxLength = 200;
			this.tbDescricaoPeca.Multiline = true;
			this.tbDescricaoPeca.Name = "tbDescricaoPeca";
			this.tbDescricaoPeca.Size = new System.Drawing.Size(285, 93);
			this.tbDescricaoPeca.TabIndex = 25;
			// 
			// GerirPedidos
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.BackColor = System.Drawing.Color.WhiteSmoke;
			this.ClientSize = new System.Drawing.Size(999, 660);
			this.Controls.Add(this.btPedidosTabulados);
			this.Controls.Add(this.lboxPedidos);
			this.Controls.Add(this.groupBox1);
			this.Controls.Add(this.gpClientes);
			this.Controls.Add(this.panel1);
			this.Controls.Add(this.menuStrip);
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
			this.Name = "GerirPedidos";
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "GerirPedidos";
			this.Load += new System.EventHandler(this.GerirPedidos_Load);
			this.menuStrip.ResumeLayout(false);
			this.menuStrip.PerformLayout();
			this.panel1.ResumeLayout(false);
			this.groupBox1.ResumeLayout(false);
			this.groupBox1.PerformLayout();
			this.gpClientes.ResumeLayout(false);
			this.gpClientes.PerformLayout();
			this.ResumeLayout(false);
			this.PerformLayout();

		}

		#endregion

		private System.Windows.Forms.MenuStrip menuStrip;
		private System.Windows.Forms.ToolStripMenuItem menuToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem gerirClientesToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem gerirToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem gerirArranjosToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem gerirFornecedoresToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem sairToolStripMenuItem;
		private System.Windows.Forms.Panel panel1;
		private System.Windows.Forms.Button button1;
		private System.Windows.Forms.ListBox lboxPedidos;
		private System.Windows.Forms.GroupBox groupBox1;
		private System.Windows.Forms.ComboBox cbTipoPedido;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.ComboBox cbCliente;
		private System.Windows.Forms.Button btAdicionarPedido;
		private System.Windows.Forms.Label label6;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.TextBox tbObservacoes;
		private System.Windows.Forms.GroupBox gpClientes;
		private System.Windows.Forms.Button btAtualizarPedido;
		private System.Windows.Forms.Button btApagarPedido;
		private System.Windows.Forms.Label label12;
		private System.Windows.Forms.Label label11;
		private System.Windows.Forms.Label label10;
		private System.Windows.Forms.CheckBox checkBox2;
		private System.Windows.Forms.CheckBox checkBox1;
		private System.Windows.Forms.TextBox textBox1;
		private System.Windows.Forms.Label label9;
		private System.Windows.Forms.Label label8;
		private System.Windows.Forms.Label label7;
		private System.Windows.Forms.Label label5;
		private System.Windows.Forms.Label label4;
		private System.Windows.Forms.Label label3;
		private System.Windows.Forms.ComboBox cbPeca;
		private System.Windows.Forms.Label label13;
		private System.Windows.Forms.Button btPedidosTabulados;
		private System.Windows.Forms.TextBox tbPedidoNaoTabelado;
		private System.Windows.Forms.CheckBox cboxPedidoNaoTabelado;
		private System.Windows.Forms.ComboBox cbCorPeca;
		private System.Windows.Forms.Label label14;
		private System.Windows.Forms.Label label15;
		private System.Windows.Forms.TextBox tbDescricaoPeca;
	}
}