﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Projeto_DAplicacoes
{
	public partial class GerirArranjos : Form
	{
		private CRSMContainer bd;
		public GerirArranjos()
		{
			InitializeComponent();
		}

		private void sairToolStripMenuItem_Click(object sender, EventArgs e)
		{
			if (MessageBox.Show("Tem a certeza que pretende sair?", "Confirmar saída", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
			{
				Application.Exit();
			}
		}

		private void gerirArranjosToolStripMenuItem_Click(object sender, EventArgs e)
		{

		}

		private void gerirClientesToolStripMenuItem_Click(object sender, EventArgs e)
		{
			this.Hide();
			GerirClientes form = new GerirClientes();
			form.Show();
		}

		private void gerirFornecedoresToolStripMenuItem_Click(object sender, EventArgs e)
		{
			this.Hide();
			GerirFornecedorMaterial form = new GerirFornecedorMaterial();
			form.Show();
		}
		private void gerirToolStripMenuItem_Click(object sender, EventArgs e)
		{
			this.Hide();
			GerirPedidos form = new GerirPedidos();
			form.Show();
		}

		private void btVerificarArranjosTabelados_Click(object sender, EventArgs e)
		{
			this.Hide();
			TabelaArranjos form = new TabelaArranjos();
			form.Show();
		}

		private void GerirArranjos_Load(object sender, EventArgs e)
		{
			bd = new CRSMContainer();
			LerDados();
			cbCorPeca.Items.Insert(0, "Amarelo");
			cbCorPeca.Items.Insert(1, "Azul");
			cbCorPeca.Items.Insert(2, "Branco");
			cbCorPeca.Items.Insert(3, "Cinzento");
			cbCorPeca.Items.Insert(4, "Laranja");
			cbCorPeca.Items.Insert(5, "Rosa");
			cbCorPeca.Items.Insert(6, "Vermelho");
			cbCorPeca.Items.Insert(7, "Vermelho");
			cbCorPeca.Items.Insert(8, "Violeta");
			cbCorPeca.Items.Insert(9, "Verde");
		}

		private void LerDados()
		{
			cbTipoArranjo.DataSource = bd.ArranjoSet.ToList<Arranjo>();
			cbPeca.DataSource = bd.PecaSet.ToList<Peca>();
			cbCliente.DataSource = bd.ClienteSet.ToList<Cliente>();
		}

		private void btConfirmarArranjo_Click(object sender, EventArgs e)
		{
			Trabalho trabalho = new Trabalho();

			if ((cbTipoArranjo.Text == "Colocar Fecho") && (cbPeca.Text == "Id:1, Casaco"))
			{
				trabalho.ValorPago = 10;
			}
			else if ((cbTipoArranjo.Text == "Colocar Fecho") && (cbPeca.Text != "Id:1, Casaco"))
			{
				trabalho.ValorPago = 7;
			}
			else
			{
				trabalho.ValorPago = 5;
			}

			trabalho.PedidoTabelado.Cliente.Nome = cbCliente.Text;
		}
	}
}
