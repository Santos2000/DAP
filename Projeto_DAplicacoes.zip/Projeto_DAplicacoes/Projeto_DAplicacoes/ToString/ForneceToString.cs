﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Projeto_DAplicacoes
{
	using System;
	using System.Collections.Generic;
	public partial class Fornece
	{
		public override string ToString()
		{
			return string.Format("ID:{0}, Fornecido por: {1}, Data de entrega:{2}, Preço:{3}",StockMateriais.Id, Fornecedor.Nome, PrazoEntrega, Preco);
		}
	}
}
