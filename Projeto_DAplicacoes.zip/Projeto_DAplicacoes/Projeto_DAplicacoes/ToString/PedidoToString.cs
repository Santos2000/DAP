﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Projeto_DAplicacoes
{
	using System;
	using System.Collections.Generic;
	public partial class Pedido
	{
		public override string ToString()
		{
			return string.Format("ID:{0}, feito por:{1}, no dia:{2}", Id, Cliente.Nome, DataPedido);
		}
	}
}
